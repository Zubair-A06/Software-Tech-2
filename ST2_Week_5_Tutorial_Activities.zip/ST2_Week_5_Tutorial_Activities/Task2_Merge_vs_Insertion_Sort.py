
# Task 2
# Test data sizes
import random
import timeit

from recursion_mergesort import insertion_sort, merge_sort


for size in [10, 20, 50]:
    random_list = [random.randint(1, size * 10) for _ in range(size)]

    merge_time = timeit.timeit(lambda: merge_sort(random_list[:]), number=1)
    insertion_time = timeit.timeit(lambda: insertion_sort(random_list[:]), number=1)

    print(f"\nList size = {size}")
    print(f"Merge Sort time: {merge_time:.6f} seconds")
    print(f"Insertion Sort time: {insertion_time:.6f} seconds")