from tkinter import *

class SierpinskiApp:
    def __init__(self):
        window = Tk()
        window.title("Sierpinski Triangle")

        self.canvas_width = 400
        self.canvas_height = 400

        self.canvas = Canvas(window, width=self.canvas_width, height=self.canvas_height)
        self.canvas.pack()

        input_frame = Frame(window)
        input_frame.pack(pady=10)

        Label(input_frame, text="Enter an order: ").pack(side=LEFT, padx=(0,5))
        self.order_input = StringVar()
        Entry(input_frame, textvariable=self.order_input, justify=RIGHT).pack(side=LEFT, padx=5)
        Button(input_frame, text="Display Triangle", command=self.show_triangle).pack(side=LEFT, padx=(5,0))

        window.mainloop()

    def show_triangle(self):
        order_value = int(self.order_input.get())

        self.canvas.delete("line")

        point_a = [self.canvas_width / 2, 10]
        point_b = [10, self.canvas_height - 10]
        point_c = [self.canvas_width - 10, self.canvas_height - 10]

        self.draw_triangle(order_value, point_a, point_b, point_c)

    def draw_triangle(self, level, a, b, c):
        if level == 0:
            self.draw_edge(a, b)
            self.draw_edge(b, c)
            self.draw_edge(c, a)
        else:
            ab_mid = self.get_midpoint(a, b)
            bc_mid = self.get_midpoint(b, c)
            ca_mid = self.get_midpoint(c, a)

            self.draw_triangle(level - 1, a, ab_mid, ca_mid)
            self.draw_triangle(level - 1, ab_mid, b, bc_mid)
            self.draw_triangle(level - 1, ca_mid, bc_mid, c)

    def draw_edge(self, start, end):
        self.canvas.create_line(start[0], start[1], end[0], end[1], tags="line")

    def get_midpoint(self, point1, point2):
        return [(point1[0] + point2[0]) / 2, (point1[1] + point2[1]) / 2]

SierpinskiApp()