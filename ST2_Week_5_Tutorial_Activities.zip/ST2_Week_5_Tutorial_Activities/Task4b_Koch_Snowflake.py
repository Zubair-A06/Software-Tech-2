from tkinter import *
import math

class KochApp:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        self.canvas_width = 500
        self.canvas_height = 500

        self.canvas = Canvas(window, width=self.canvas_width, height=self.canvas_height)
        self.canvas.pack()

        input_frame = Frame(window)
        input_frame.pack()

        Label(input_frame, text="Enter an order: ").pack(side=LEFT, padx=(0,5))
        self.order_input = StringVar()
        Entry(input_frame, textvariable=self.order_input, justify=RIGHT).pack(side=LEFT, padx=5)
        Button(input_frame, text="Display", command=self.show_snowflake).pack(side=LEFT, padx=(5,0))

        window.mainloop()

    def show_snowflake(self):
        size = 300

        point_a = [self.canvas_width / 2 - size / 2, self.canvas_height / 2 + size / 3]
        point_b = [self.canvas_width / 2 + size / 2, self.canvas_height / 2 + size / 3]
        triangle_height = size * math.sqrt(3) / 2
        point_c = [self.canvas_width / 2, self.canvas_height / 2 - 2 * triangle_height / 3]

        level = int(self.order_input.get())

        for start, end in ((point_a, point_b), (point_b, point_c), (point_c, point_a)):
            self.draw_koch_line(start, end, level)

    def draw_koch_line(self, start, end, level):
        if level == 0:
            self.canvas.create_line(start[0], start[1], end[0], end[1], tags="line")
        else:
            dx = (end[0] - start[0]) / 3
            dy = (end[1] - start[1]) / 3

            point_1 = [start[0] + dx, start[1] + dy]
            point_2 = [start[0] + 2 * dx, start[1] + 2 * dy]

            angle = math.radians(60)
            peak_x = point_1[0] + math.cos(angle) * (point_2[0] - point_1[0]) - math.sin(angle) * (point_2[1] - point_1[1])
            peak_y = point_1[1] + math.sin(angle) * (point_2[0] - point_1[0]) + math.cos(angle) * (point_2[1] - point_1[1])
            peak_point = [peak_x, peak_y]

            self.draw_koch_line(start, point_1, level - 1)
            self.draw_koch_line(point_1, peak_point, level - 1)
            self.draw_koch_line(peak_point, point_2, level - 1)
            self.draw_koch_line(point_2, end, level - 1)

KochApp()