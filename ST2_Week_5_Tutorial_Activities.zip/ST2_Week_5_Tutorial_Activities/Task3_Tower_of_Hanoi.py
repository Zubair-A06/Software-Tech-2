  #Task 3:
    # Tower of Hanoi

move_count = 0  # Global variable to count moves

def run_hanoi():
    global move_count

    disk_count = int(input("Enter number of disks: "))
    print("The moves are:")

    solve_hanoi(disk_count, 'A', 'B', 'C')

    print("Number of moves is", move_count)

def solve_hanoi(disks, source, destination, auxiliary):
    global move_count

    if disks == 1:
        move_count += 1
        print(f"Move disk 1 from {source} to {destination}")
        return

    solve_hanoi(disks - 1, source, auxiliary, destination)

    move_count += 1
    print(f"Move disk {disks} from {source} to {destination}")

    solve_hanoi(disks - 1, auxiliary, destination, source)

run_hanoi()
